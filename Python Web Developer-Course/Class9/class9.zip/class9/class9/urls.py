from django.conf.urls import patterns, include, url

from django.contrib import admin

from servermanager.views import index, account_login, account_logout

admin.autodiscover()
urlpatterns = patterns('',
    url(r'^servermanager/', include('servermanager.urls', namespace='servermanager')),
    url(r'^admin/', include(admin.site.urls)),
    url(r'^$', index, name='index'),
    url(r'^account-login/$', account_login, name='account_login'),
    url(r'^account-logout/$', account_logout, name='account_logout')

)
