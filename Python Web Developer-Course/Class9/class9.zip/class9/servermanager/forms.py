from django.forms import ModelForm
from servermanager.models import Ipinfo


class IpinfoForms(ModelForm):

    class Meta:
        model = Ipinfo
        # fields