from django.db import models


class Ipinfo(models.Model):
    ip = models.IPAddressField()
    user = models.CharField(max_length=16)
    cpu = models.TextField()

    def __unicode__(self):
        return self.ip


