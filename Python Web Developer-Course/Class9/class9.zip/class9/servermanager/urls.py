from django.conf.urls import patterns, include, url
from servermanager.views import ipserver, ipserver_detail, ip_add, ip_delete, delete_confirm, ip_edit, search
urlpatterns = patterns('',
    url(r'^ipserver/$', ipserver, name='ipserver'),
    url(r'^ipserver-detail/(?P<id>.*)/$', ipserver_detail, name='ipserver-detail'),
    url(r'^add/$', ip_add, name='add'),
    url(r'^edit/(?P<id>.*)/$', ip_edit, name='edit'),
    url(r'^delete-ip/(?P<id>.*)/$', ip_delete, name='delete'),
    url(r'^delete-confirm/$',delete_confirm, name='delete_confirm'),
    url(r'^search/$',search, name='search'),
)
