# coding:utf-8
import json

from django.shortcuts import render
from servermanager.models import Ipinfo
from servermanager.forms import IpinfoForms
from django.contrib import auth
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse
from django.http import HttpResponse


@csrf_exempt
def account_login(request):
    username = request.POST.get('username', '')
    password = request.POST.get('password', '')
    user = auth.authenticate(username=username, password=password)
    if user is not None and user.is_active:
        auth.login(request, user)
        return HttpResponseRedirect(reverse("servermanager:ipserver"))
    else:
        error = "用户名或者密码出错"
    return render(request, "index.html", {'login_error': error})


def account_logout(request):
    auth.logout(request)
    # Redirect to a success page.
    return HttpResponseRedirect(reverse('index'))

def index(request):
    return render(request, "index.html")

def ipserver(request):
    ipinfo = Ipinfo.objects.all()
    return render(request, 'servermanager/iplist.html', {'ipinfo':ipinfo})


def ipserver_detail(request, id):
    if request.method == 'POST':
        form = IpinfoForms(request.POST)
    else:
        ipinfo = Ipinfo.objects.get(id=id)
        form = IpinfoForms(instance=ipinfo)
    return render(request, 'servermanager/ipdetail.html', {'form':form, 'id':id})


@csrf_exempt
def ip_add(request):
    if request.method == 'POST':
        form = IpinfoForms(request.POST)
        if form.is_valid():
            new_article = form.save()
            return HttpResponseRedirect('/servermanager/ipserver')
    else:
        form = IpinfoForms()
    return render(request, 'servermanager/add.html', {'form':form})


@csrf_exempt
def ip_edit(request, id):
    if request.method == 'POST':
        a = Ipinfo.objects.get(id=id)
        form = IpinfoForms(request.POST, instance=a)
        if form.is_valid():
            new_article = form.save()
            return HttpResponseRedirect('/servermanager/ipserver')
    else:
        form = IpinfoForms()
    return render(request, 'servermanager/add.html', {'form':form})

def ip_delete(request, id):

    ipinfo = Ipinfo.objects.get(id=id)
    ipinfo.delete()
    print request.POST
    return HttpResponseRedirect('/servermanager/delete-confirm')


def delete_confirm(request):
    return render(request, 'servermanager/delete_confirm.html')

@csrf_exempt
def search(request):
    # print request.POST
    search_key = request.POST['search_key']
    print search_key
    #result = Ipinfo.objects.filter(ip = search_key)
    #print result
    # if result:
    #     request_ip = [ i['ip'] for i in request.values('ip') ]
    #     result_dict = dict(result = request_ip)
    #     return HttpResponse(json.dumps(result_dict))
    return HttpResponse("hahha")